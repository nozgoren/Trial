# -*- coding: utf-8 -*-
"""


"""


import numpy as np



#Change folder name to calculate data

ball_weigth=0.436
cap=0.1114
ball='7_5'   #Hesaplaması yapılmak istenen top iş basıncı ve deneme numarası- girilir
data_name_hesap=ball+"_metrik_hesap.txt"
data_vel=ball+'_velocity.txt'
data_acc=ball+'_accerelation.txt'
data_force=ball+'_force.txt'
data_impact_force=ball+'_impact_force.txt'
spring_damp=ball+'_spring_damper.txt'
areas=ball+'_area.txt'



data_name_force=ball+'_force.txt'

rms_folder_path=ball+'_area.txt'





#%%
#velocity calculate block
data=np.genfromtxt(data_name_hesap,delimiter=" ", usecols=(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14))
velocity=open(data_vel,'w')
a=len(data)

for i in range(0,a-2):
    x_range=data[i][0]
    x_range2=data[i+2][0]
    y_range=data[i][1]
    y_range2=data[i+2][1]
    vel_x1=(x_range2-x_range)/(2*1/4000)
    vel_y1=(y_range2-y_range)/(2*1/4000)
    resultant_velocity=(vel_x1**2+vel_y1**2)**0.5
    velocity.write(str(vel_x1)+' '+str(vel_y1)+' '+str(resultant_velocity)+'\n')
    
    
velocity.close()

#%%  ball mass during collision

ball_volume=(4*3.14*cap**2)

ball_mass=[]
ball_mass2=[]
for i in range(0,len(data)):
    a_h=(data[i][7]/2)
    
    ball_v=(3.14*(a_h**2+((data[i][3])**2)))
    
    ball_mass.append(ball_weigth-(ball_v*ball_weigth)/ball_volume)
    
    
    
    if a_h != 0:
        ball_mass2.append((ball_weigth-(ball_v*ball_weigth)/ball_volume))
    

    
#%%

#acceleration calculate block


data_hiz=np.genfromtxt(data_vel,delimiter=" ", usecols=(0,1,2))
acceleration=open(data_acc,'w')
for i in range(0,a-4):
    x_range=data_hiz[i][0]
    x_range2=data_hiz[i+2][0]
    y_range=data_hiz[i][1]
    y_range2=data_hiz[i+2][1]
    acc_x1=(x_range2-x_range)/(2*1/4000)
    acc_y1=(y_range2-y_range)/(2*1/4000)
    resultant_acc=(acc_x1**2+acc_y1**2)**0.5
    acceleration.write(str(acc_x1)+' '+str(acc_y1)+' '+str(resultant_acc)+'\n')
   
acceleration.close()

#%%  
#linear force calculate block

data3=np.genfromtxt(data_acc,delimiter=" ", usecols=(0,1,2))

force=open(data_force,'w')

for i in range(0,a-4):
    f_x1=data3[i][0]*ball_mass[i] #yatay kuvvet
    f_y1=data3[i][1]*ball_mass[i] #dikey kuvvet
    f_f=(f_x1**2+f_y1**2)**0.5  #bileÅke kuvvet
    force.write(str(f_x1)+' '+str(f_y1)+' '+str(f_f)+'\n')
    
force.close()   

#%%area calculate block
alan=open(areas,'w')   
for i in range(0,len(data)):
    ccc= data[i][12]
    if ccc != 0:
        alan.write(str(data[i][12])+'\n')

#to  calculate coeficient of restitution:together with inbound and rebound velocity
inbound=[]
rebound=[]
r=len(data)
num=1
alan.close()
 # to detect impact moment and impact moment row   
for i in range(0,r-1):
    if data[i][3]!=0:
        break
    else:
        num=num+1
        

inbound_velocity=0

# calculate mean inbound velocity (10 frame)
for i in range(num-11,num-1,1):
    inbound_velocity=((data_hiz[i][2]+inbound_velocity))
    
inbound_velocity=inbound_velocity/10

num2=0
for i in range(0,r-1):
    if data[i][3]!=0:
        num2=num2+1
        deformation=(data[:,3])
time=1

def_max=max(deformation)


#%%


# calculate mean rebound velocity (10 frame)
for i in range(num-1,num+num2+1,1):
    if data[i][3]==def_max:
        break
    else:
        time=time+1
        
rebound_velocity=0

for i in range(num+num2-3,num+num2+7,1):
    rebound_velocity=((data_hiz[i][2]+rebound_velocity)) 
 
    side_view_min_area=min(data[:,12])
rebound_velocity2=rebound_velocity/10



#%%


#impact force block:start from initial to end
data_sd=np.genfromtxt(data_force,delimiter=" ", usecols=(0,1,2))
data2=open(data_impact_force,'w')


for j in range(num-3,num+num2-3):
    
    force_impact0=data_sd[j][0] #horizontal force
    force_impact1=data_sd[j][1] #vertical force
    force_impact2=data_sd[j][2] #resultant force
    
    data2.write(str(force_impact0)+' '+str(force_impact1)+' '+str(force_impact2)+'\n')
        
data2.close()



#%%


#spring and damper calculate block
data_sd=np.genfromtxt(data_impact_force,delimiter=" ", usecols=(2))

data_spring=open(spring_damp,'w')  #tüm verileri yazmak için açılan dosya
data2_metrik=np.genfromtxt(data_name_hesap,delimiter=" ", usecols=(3))
data_spring2=np.genfromtxt(data_vel,delimiter=" ", usecols=(0,1,2))
length=len(data_sd)
v_first=data_spring2[num-2][0]
v_final=data_spring2[num+num2-3][0]

average_force= np.mean(data_sd)

max_force=max(data_sd)  

val2=max(data2_metrik)

spring=(average_force/val2)*2

c=2*(spring*ball_weigth)**0.5


#%%calculate impact area
    


data6=np.genfromtxt(data_name_hesap,delimiter=" ", usecols=(12))        
for i in range(num+1, num+num2-5):
    side_view_max_area=max(data6)
    side_view_min_area=data[num-1][12]
       

time_impact=time*1/4000


#%%


file_area=np.genfromtxt(areas,delimiter=' ',usecols=(0))
file_impact=np.genfromtxt(data_impact_force,delimiter=' ',usecols=(0,1,2))

file_of_area=np.zeros((time,2))


data_spring.write('Impact_Time_(to_max_def.):'+' '+str('%3.5f' %time_impact)+'\n'+
                  'Total_Impact_Time:'+' '+str(num2*1/4000)+'\n'+
                  'Max_Deformation:'+' '+str(def_max)+'\n'+
                  'Spring:'+' '+str(spring)+'\n'+'Damper:'+' '+str(c)+'\n'+
                  'Inbound_Velocity:'+' '+str(inbound_velocity)+'\n'+
                  'Rebound_Velocity:'+' '+str(rebound_velocity2)+'\n'+
                  'CoR:'+' '+str(rebound_velocity2/inbound_velocity)+'\n'+
                  'Max_Force:'+' '+str(max_force)+'\n'+
                  'Average_Force:'+' '+str(average_force)+'\n'+
                  'Max_Area_Side:'+' '+str(side_view_max_area)+'\n'+
                 
                  'Min_Area_Side:'+' '+str('%3.8f' %side_view_min_area)+'\n')
                 
            
                 
                   
data_spring.close()


