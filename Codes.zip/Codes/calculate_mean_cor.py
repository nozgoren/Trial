# -*- coding: utf-8 -*-
"""



"""


import numpy as np
import matplotlib.pyplot as plt
import statistics
name='4'


cap=22.28
name1=name+'_1'
name2=name+'_2'
name3=name+'_3'
name4=name+'_4'
name5=name+'_5'

file=open(name+'_mean_comp_cor.txt','w')
file2=open(name+'_mean_res_cor.txt','w')
file3=open(name+'_mean_cor_gir.txt','w')

x_path1=name1
x_path2=name2
x_path3=name3
x_path4=name4
x_path5=name5





data1=np.genfromtxt(x_path1+'_cor_compr_phase.txt',delimiter=' ',usecols=(0))
data2=np.genfromtxt(x_path2+'_cor_compr_phase.txt',delimiter=' ',usecols=(0))
data3=np.genfromtxt(x_path3+'_cor_compr_phase.txt',delimiter=' ',usecols=(0))
data4=np.genfromtxt(x_path4+'_cor_compr_phase.txt',delimiter=' ',usecols=(0))
data5=np.genfromtxt(x_path5+'_cor_compr_phase.txt',delimiter=' ',usecols=(0))

data2_1=np.genfromtxt(x_path1+'_cor_res_phase.txt',delimiter=' ',usecols=(0))
data2_2=np.genfromtxt(x_path2+'_cor_res_phase.txt',delimiter=' ',usecols=(0))
data2_3=np.genfromtxt(x_path3+'_cor_res_phase.txt',delimiter=' ',usecols=(0))
data2_4=np.genfromtxt(x_path4+'_cor_res_phase.txt',delimiter=' ',usecols=(0))
data2_5=np.genfromtxt(x_path5+'_cor_res_phase.txt',delimiter=' ',usecols=(0))

data12=np.genfromtxt(x_path1+'_metrik_hesap.txt',delimiter=' ',usecols=(3)) #The name of the file containing the collision parameters is _metrik_hesap, 4_1_metrik_hesap.txt etc.
data22=np.genfromtxt(x_path2+'_metrik_hesap.txt',delimiter=' ',usecols=(3))
data32=np.genfromtxt(x_path3+'_metrik_hesap.txt',delimiter=' ',usecols=(3))
data42=np.genfromtxt(x_path4+'_metrik_hesap.txt',delimiter=' ',usecols=(3))
data52=np.genfromtxt(x_path5+'_metrik_hesap.txt',delimiter=' ',usecols=(3))

#%%
'''in order to calculate mean EDDC for all CP'''

cor1=[]
cor2=[]
cor3=[]
cor4=[]
cor5=[]



cor_comp=[]
cor_res=[]
dev_comp=[]
dev_rest=[]
for i in range(0,len(data1)):   
    cor1.append((data1[i]))         
for i in range(0,len(data2)):
    cor2.append((data2[i]))
for i in range(0,len(data3)):
    cor3.append((data3[i]))
for i in range(0,len(data4)):
    cor4.append((data4[i]))
for i in range(0,len(data5)):
    cor5.append((data5[i]))  

b=20
for g in range(0,20):

    c1=cor1[int(round((len(cor1)/b)*(g),0))]
    c2=cor2[int(round((len(cor2)/b)*(g),0))]
    c3=cor3[int(round((len(cor3)/b)*(g),0))]
    c4=cor4[int(round((len(cor4)/b)*(g),0))]
    c5=cor5[int(round((len(cor5)/b)*(g),0))]


        
    v=(c1,c2,c3,c4,c5)
  
    cor_mean=statistics.mean(v)
    
    dev=statistics.stdev(v)
    cor_comp.append(cor_mean)
    dev_comp.append(dev)

#%%
'''in order to calculate mean eddc for all RP'''
cor2_1=[]
cor2_2=[]
cor2_3=[]
cor2_4=[]
cor2_5=[]
  

for i in range(0,len(data2_1)):   
    cor2_1.append((data2_1[i]))         
for i in range(0,len(data2_1)):
    cor2_2.append((data2_1[i]))
for i in range(0,len(data2_3)):
    cor2_3.append((data2_3[i]))
for i in range(0,len(data2_4)):
    cor2_4.append((data2_4[i]))
for i in range(0,len(data2_5)):
    cor2_5.append((data2_5[i]))  

b=20
for g in range(0,20):

    c2_1=cor2_1[int(round((len(cor2_1)/b)*(g),0))]
    c2_2=cor2_2[int(round((len(cor2_2)/b)*(g),0))]
    c2_3=cor2_3[int(round((len(cor2_3)/b)*(g),0))]
    c2_4=cor2_4[int(round((len(cor2_4)/b)*(g),0))]
    c2_5=cor2_5[int(round((len(cor2_5)/b)*(g),0))]

 

        
    v2=(c2_1,c2_2,c2_3,c2_4,c2_5)
  
    cor_mean_res=statistics.mean(v2)
    
    dev_res=statistics.stdev(v2)
    cor_res.append(cor_mean_res)
    dev_rest.append(dev_res)

#%%%
''' to draw graph'''

ind1=[]
ind2=[]
ind3=[]
ind4=[]
ind5=[]
ind6=[]
ind7=[]
ind8=[]
ind9=[]



ind12=[]
ind22=[]
ind32=[]
ind42=[]
ind52=[]
ind62=[]
ind72=[]
ind82=[]
ind92=[]

max1=max(data12)
max2=max(data22)
max3=max(data32)
max4=max(data42)
max5=max(data52)


gir_data_com=[]
gir_data_res=[]



i=0
for i in range(0,len(data12)):  
    if data12[i]!=0 and data12[i]==max1:
        break
    if data12[i]!=0:
        ind1.append(data12[i])
        i+=1
        continue
for j in range(i+1,len(data12)):
    if data12[j]!=0:
        ind12.append(data12[j])
    
i=0
for i in range(0,len(data22)):  
    if data22[i]!=0 and data22[i]==max2:
        break
    if data22[i]!=0:
        ind2.append(data22[i])
        i+=1
        continue
for j in range(i+1,len(data22)):
    if data22[j]!=0:
        ind22.append(data22[j])            


i=0
for i in range(0,len(data32)):  
    if data32[i]!=0 and data32[i]==max3:
        break
    if data32[i]!=0:
        ind3.append(data32[i])
        i+=1
        continue
for j in range(i+1,len(data32)):
    if data32[j]!=0:
        ind32.append(data32[j])            

i=0
for i in range(0,len(data42)):  
    if data42[i]!=0 and data42[i]==max4:
        break
    if data42[i]!=0:
        ind4.append(data42[i])
        i+=1
        continue
for j in range(i+1,len(data42)):
    if data42[j]!=0:
        ind42.append(data42[j])            

i=0
for i in range(0,len(data52)):  
    if data52[i]!=0 and data52[i]==max5:
        break
    if data52[i]!=0:
        ind5.append(data52[i])
        i+=1
        continue
for j in range(i+1,len(data52)):
    if data52[j]!=0:
        ind52.append(data52[j])   

i=0

b=20
for g in range(0,20):

    g1=ind1[int(round((len(ind1)/b)*(g),0))]
    g2=ind2[int(round((len(ind2)/b)*(g),0))]
    g3=ind3[int(round((len(ind3)/b)*(g),0))]
    g4=ind4[int(round((len(ind4)/b)*(g),0))]
    g5=ind5[int(round((len(ind5)/b)*(g),0))]
 

        
    gir_com=(g1,g2,g3,g4,g5)
  
    gir_mean_com=statistics.mean(gir_com)
    dev_gir_com=statistics.stdev(gir_com)
    gir_data_com.append(gir_mean_com/cap*100)



b=20
for g in range(0,20):

    g12=ind12[int(round((len(ind12)/b)*(g),0))]
    g22=ind22[int(round((len(ind22)/b)*(g),0))]
    g32=ind32[int(round((len(ind32)/b)*(g),0))]
    g42=ind42[int(round((len(ind42)/b)*(g),0))]
    g52=ind52[int(round((len(ind52)/b)*(g),0))]
 
 

        
    gir_res=(g12,g22,g32,g42,g52)
  
    gir_mean_res=statistics.mean(gir_res)
    dev_res=statistics.stdev(gir_res)
    gir_data_res.append(gir_mean_res/cap*100)

for i in range(0,len(cor_comp)):
    file.write(str(cor_comp[i])+' '+str(dev_comp[i])+' '+str(gir_data_com[i])+'\n')
    file3.write(str(cor_comp[i])+' '+str(dev_comp[i])+' '+str(gir_data_com[i])+'\n')
file.close()

for i in range(0,len(cor_res)):
    file2.write(str(cor_res[i])+' '+str(dev_rest[i])+' '+str(gir_data_res[i])+'\n')
    file3.write(str(cor_res[i])+' '+str(dev_rest[i])+' '+str(gir_data_res[i])+'\n')
file2.close()


    
plt.plot(gir_data_com,cor_comp,'k',label='Compression')
plt.plot(gir_data_res,cor_res,'r',label='Restitution')
plt.legend(fontsize=10)
plt.grid(':')
plt.ylim(0.5,1.1)
plt.xlim(0,0.2)
plt.ylabel('COR',fontsize=12)
plt.xlabel('Indentation ratio',fontsize=12)
plt.title(' Mean COR')
plt.show()

file3.close()