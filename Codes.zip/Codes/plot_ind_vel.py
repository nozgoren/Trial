# -*- coding: utf-8 -*-
"""



"""

import numpy as np
import matplotlib.pyplot as plt

fig, ((ax, ax1), (ax2, ax3)) = plt.subplots(2, 2)
plt.figsize=(18,4)



model1=np.genfromtxt('4_1_runga_kutta_outputs.txt',delimiter=' ',usecols=(0,1,2,3))
model2=np.genfromtxt('4_2_runga_kutta_outputs.txt',delimiter=' ',usecols=(0,1,2,3))
model3=np.genfromtxt('4_3_runga_kutta_outputs.txt',delimiter=' ',usecols=(0,1,2,3))
model4=np.genfromtxt('4_4_runga_kutta_outputs.txt',delimiter=' ',usecols=(0,1,2,3))
model5=np.genfromtxt('4_5_runga_kutta_outputs.txt',delimiter=' ',usecols=(0,1,2,3))

model11=np.genfromtxt('5_1_runga_kutta_outputs.txt',delimiter=' ',usecols=(0,1,2,3))
model21=np.genfromtxt('5_2_runga_kutta_outputs.txt',delimiter=' ',usecols=(0,1,2,3))
model31=np.genfromtxt('5_3_runga_kutta_outputs.txt',delimiter=' ',usecols=(0,1,2,3))
model41=np.genfromtxt('5_4_runga_kutta_outputs.txt',delimiter=' ',usecols=(0,1,2,3))
model51=np.genfromtxt('5_5_runga_kutta_outputs.txt',delimiter=' ',usecols=(0,1,2,3))

deney1=np.genfromtxt('6_1_runga_kutta_outputs.txt',delimiter=' ',usecols=(0,1,2,3))
deney2=np.genfromtxt('6_2_runga_kutta_outputs.txt',delimiter=' ',usecols=(0,1,2,3))
deney3=np.genfromtxt('6_3_runga_kutta_outputs.txt',delimiter=' ',usecols=(0,1,2,3))
deney4=np.genfromtxt('6_4_runga_kutta_outputs.txt',delimiter=' ',usecols=(0,1,2,3))
deney5=np.genfromtxt('6_5_runga_kutta_outputs.txt',delimiter=' ',usecols=(0,1,2,3))


deney11=np.genfromtxt('7_1_runga_kutta_outputs.txt',delimiter=' ',usecols=(0,1,2,3))
deney21=np.genfromtxt('7_2_runga_kutta_outputs.txt',delimiter=' ',usecols=(0,1,2,3))
deney31=np.genfromtxt('7_3_runga_kutta_outputs.txt',delimiter=' ',usecols=(0,1,2,3))
deney41=np.genfromtxt('7_4_runga_kutta_outputs.txt',delimiter=' ',usecols=(0,1,2,3))
deney51=np.genfromtxt('7_5_runga_kutta_outputs.txt',delimiter=' ',usecols=(0,1,2,3))




#x11=sorted(deney1[:,0],reverse=False)
#x12=sorted(deney2[:,0],reverse=False)
#x13=sorted(deney3[:,0],reverse=False)
#x14=sorted(deney4[:,0],reverse=False)

x1=[]
x2=[]
x3=[]
x4=[]
x5=[]

x11=[]
x21=[]
x31=[]
x41=[]
x51=[]

x111=[]
x211=[]
x311=[]
x411=[]
x511=[]


x1111=[]
x2111=[]
x3111=[]
x4111=[]
x5111=[]

for i in range(0,len(model1)):   
    norm1=((i+1-1)/(len(model1)-1))*100
    x1.append(norm1)
    
for i in range(0,len(model2)):   
    norm2=((i+1-1)/(len(model2)-1))*100
    x2.append(norm2)

for i in range(0,len(model3)):   
    norm3=((i+1-1)/(len(model3)-1))*100
    x3.append(norm3)
    
for i in range(0,len(model4)):   
    norm4=((i+1-1)/(len(model4)-1))*100
    x4.append(norm4)
    
for i in range(0,len(model5)):   
    norm5=((i+1-1)/(len(model5)-1))*100
    x5.append(norm5)
 
#2.hız
    
for i in range(0,len(model1)):   
    norm11=((i+1-1)/(len(model1)-1))*100
    x11.append(norm11)
    
for i in range(0,len(model21)):   
    norm21=((i+1-1)/(len(model21)-1))*100
    x21.append(norm2)

for i in range(0,len(model31)):   
    norm31=((i+1-1)/(len(model31)-1))*100
    x31.append(norm31)
    
for i in range(0,len(model41)):   
    norm41=((i+1-1)/(len(model41)-1))*100
    x41.append(norm41)
    
for i in range(0,len(model51)):   
    norm51=((i+1-1)/(len(model51)-1))*100
    x51.append(norm51)
    
#3.hız
    
for i in range(0,len(deney1)):   
    norm11=((i+1-1)/(len(deney1)-1))*100
    x11.append(norm11)
    
for i in range(0,len(model21)):   
    norm21=((i+1-1)/(len(model21)-1))*100
    x21.append(norm2)

for i in range(0,len(model31)):   
    norm31=((i+1-1)/(len(model31)-1))*100
    x31.append(norm31)
    
for i in range(0,len(model41)):   
    norm41=((i+1-1)/(len(model41)-1))*100
    x41.append(norm41)
    
for i in range(0,len(model51)):   
    norm51=((i+1-1)/(len(model51)-1))*100
    x51.append(norm51)
    
    
ax.plot(x1,model1[:,1],'k-',label='model')
ax.plot(x1,deney1[:,0],'k--',label='exp.')

ax.plot(x2,model2[:,1],'r-')
ax.plot(x2,deney2[:,0],'r--')

ax.plot(x3,model3[:,1],'g-')
ax.plot(x3,deney3[:,0],'g--')

ax.plot(x4,model4[:,1],'b-')
ax.plot(x4,deney4[:,0],'b--')

ax.plot(x5,model5[:,1],'y-')
ax.plot(x5,deney5[:,0],'y--')


ax1.plot(x11,model11[:,1],'k-',label='T-1 model')
ax1.plot(x11,deney11[:,0],'k--',label='T-1 exp')

ax1.plot(x21,model21[:,1],'r-',label='T-2 model')
ax1.plot(x21,deney21[:,0],'r--',label='T-2 exp')

ax1.plot(x31,model31[:,1],'g-',label='T-3 model')
ax1.plot(x31,deney31[:,0],'g--',label='T-3 exp')

ax1.plot(x41,model41[:,1],'b-',label='T-4 model')
ax1.plot(x41,deney41[:,0],'b--',label='T-4 exp')

ax1.plot(x51,model51[:,1],'y-',label='T-5 model')
ax1.plot(x51,deney51[:,0],'y--',label='T-5 exp')

ax2.plot(x111,deney111[:,0],'k--')
ax2.plot(x111,model111[:,1],'k-')

ax2.plot(x211,model211[:,1],'r-')
ax2.plot(x211,deney211[:,0],'r--')

ax2.plot(x311,model311[:,1],'g-')
ax2.plot(x311,deney311[:,0],'g--')

ax2.plot(x411,model411[:,1],'b-')
ax2.plot(x411,deney411[:,0],'b--')

ax2.plot(x511,model511[:,1],'y-')
ax2.plot(x511,deney511[:,0],'y--')

ax3.plot(x1111,model1111[:,1],'k-')
ax3.plot(x1111,deney1111[:,0],'k--')


ax3.plot(x2111,model2111[:,1],'r-')
ax3.plot(x2111,deney2111[:,0],'r--')

ax3.plot(x3111,model3111[:,1],'g-')
ax3.plot(x3111,deney3111[:,0],'g--')

ax3.plot(x4111,model4111[:,1],'b-')
ax3.plot(x4111,deney4111[:,0],'b--')

ax3.plot(x5111,model5111[:,1],'y-')
ax3.plot(x5111,deney5111[:,0],'y--')

ax.grid(':')
ax1.grid(':')
ax2.grid(':')
ax3.grid(':')
ax.set_xlabel('Time (%)', fontsize=12)
ax.set_ylabel('Velocity (m.s$^{-1})$', fontsize=12)
ax1.set_xlabel('Time (%)', fontsize=12)
ax1.set_ylabel('Velocity (m.s$^{-1})$', fontsize=12)
ax2.set_xlabel('Time (%)', fontsize=12)
ax2.set_ylabel('Velocity (m.s$^{-1})$', fontsize=12)
ax3.set_xlabel('Time (%)', fontsize=12)
ax3.set_ylabel('Velocity (m.s$^{-1})$', fontsize=12)
line_labels = ['T1 model', 'T1 exp.','T2 model', 'T2 exp.','T3 model', 'T3 exp.','T4 model', 'T4 exp.','T5 model', 'T5 exp.']
ax1.legend( line_labels, loc = 'upper left', borderaxespad=0.1, ncol=6, labelspacing=0.,  prop={'size': 10} ) #bbox_to_anchor=(0.5, 0.0), borderaxespad=0.1, 

plt.grid(':')
ax.set_ylim(0,18)
ax1.set_ylim(0,18)
ax2.set_ylim(0,18)
ax3.set_ylim(0,18)
ax.set_xlim(0,100)
ax1.set_xlim(0,100)
ax2.set_xlim(0,100)
ax3.set_xlim(0,100)
ax1.legend(fontsize=10)
plt.subplots_adjust(wspace=1)
plt.show()

