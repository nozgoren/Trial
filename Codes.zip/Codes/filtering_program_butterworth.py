# -*- coding: utf-8 -*-
"""



"""
import numpy as np
import matplotlib.pyplot as plt
from scipy import signal
import itertools


q=open('7_1_filtre.txt','w')
data = np.genfromtxt('/_1_digi.txt', delimiter=' ', skip_header = 0,
usecols = (0,1,2))

# First, design the Buterworth filter
N  = 4  # Filter order
Wn =10/40 # Cutoff frequency
# Data Collectiın Rate 6000 H


b, a = signal.butter(N, Wn, 'low', output='ba')
# Use filtfilt to apply the filter.
dataF = signal.filtfilt(b, a, data.T).T # Be Careful FiltFilt wants data in rows

plt.figure(1)
plt.plot(data,'or') # RawData
plt.plot(dataF, 'k',linewidth=3) # FilteredData
plt.xlabel('[X] Piksel',fontsize=14)
plt.ylabel('[Y] Piksel',fontsize=14)
plt.legend()


plt.grid(3)
plt.show()

colors = itertools.cycle(['k'])
plt.figure(2)
for k in range(0,1,1):
    plt.plot(dataF[:,k], dataF[:,k+1],'k-',linewidth=5) # RawData


plt.plot(data[:,0], data[:,1], 'r')

plt.grid(1)
plt.xlabel('X (pixel)',fontsize=14)
plt.ylabel('Y (pixel)',fontsize=14)
plt.legend(['raw data', 'filtered data'], bbox_to_anchor=(0.0, 1), loc=2, borderaxespad=0.,fontsize=10)

plt.show()

veri=dataF



a=len(veri)

for i in veri:
    q.writelines(str(i[0]))
    q.write(' ')
    q.writelines(str(i[1]))
    q.write(' ')
    q.writelines(str(i[2])+"\n")
    
  
    

    
q.close()



